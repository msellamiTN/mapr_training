DROP TABLE IF EXISTS categories;
CREATE EXTERNAL TABLE categories (
  category_id INT,
  category_department_id INT,
  category_name STRING
)
STORED AS PARQUET
LOCATION '/user/cloudera/retail_data_raw/categories';
DROP TABLE IF EXISTS orders;
CREATE EXTERNAL TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
)
STORED AS PARQUET
LOCATION '/user/cloudera/retail_data_raw/orders';

