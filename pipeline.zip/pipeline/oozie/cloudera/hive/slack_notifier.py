import requests
import os

def post_to_slack(channel, message, token):
    """
    Function to post a message to a Slack channel
    :param channel: String, Slack channel to post the message to
    :param message: String, the message to post
    :param token: String, Slack API token
    """
    payload = {
        'channel': channel,
        'text': message
    }
    headers = {'Authorization': f'Bearer {token}'}
    response = requests.post('https://slack.com/api/chat.postMessage', json=payload, headers=headers)
    return response.json()

def main():
    # Retrieve environment variables
    slack_channel = os.getenv('SLACK_CHANNEL', '#general')
    slack_message = os.getenv('SLACK_MESSAGE', 'Hello from Oozie Workflow!')
    slack_token = os.getenv('SLACK_TOKEN')

    # Ensure Slack token is available
    if not slack_token:
        raise ValueError("Slack token is not set. Please set the SLACK_TOKEN environment variable.")

    # Post message to Slack
    response = post_to_slack(slack_channel, slack_message, slack_token)
    print("Response from Slack:", response)

if __name__ == "__main__":
    main()
