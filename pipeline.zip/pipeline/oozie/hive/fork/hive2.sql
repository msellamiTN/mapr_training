CREATE EXTERNAL TABLE order_items (
  order_item_id INT,
  order_item_order_id INT,
  order_item_product_id INT,
  order_item_quantity INT,
  order_item_subtotal FLOAT,
  order_item_product_price FLOAT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/order_items';
DROP TABLE IF EXISTS products;
CREATE EXTERNAL TABLE products (
  Product_id INT,
  Product_category_id INT,
   Product_description STRING,
  Product_price FLOAT,
  Product_image STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/products';
