#!/bin/bash

# Retrieve environment variables
SLACK_CHANNEL=${SLACK_CHANNEL:-"#general"}
SLACK_MESSAGE=${SLACK_MESSAGE:-"Hello from Oozie Workflow!"}
SLACK_TOKEN=${SLACK_TOKEN}

# Ensure Slack token is available
if [ -z "$SLACK_TOKEN" ]; then
    echo "Slack token is not set. Please set the SLACK_TOKEN environment variable."
    exit 1
fi

# Slack API URL
SLACK_API_URL="https://slack.com/api/chat.postMessage"

# Post message to Slack
RESPONSE=$(curl -s -X POST -H "Authorization: Bearer $SLACK_TOKEN" -H "Content-type: application/json" --data "{\"channel\":\"$SLACK_CHANNEL\", \"text\":\"$SLACK_MESSAGE\"}" $SLACK_API_URL)

# Print response
echo "Response from Slack: $RESPONSE"
