DROP TABLE IF EXISTS categories;
CREATE EXTERNAL TABLE categories (
  category_id INT,
  category_department_id INT,
  category_name STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/categories';

DROP TABLE IF EXISTS orders;
CREATE EXTERNAL TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/orders';

