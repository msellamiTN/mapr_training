DROP TABLE IF EXISTS categories;
CREATE EXTERNAL TABLE categories (
  category_id INT,
  category_department_id INT,
  category_name STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail_data_raw/categories';

DROP TABLE IF EXISTS orders;
CREATE EXTERNAL TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/rretail_data_raw/orders';


CREATE EXTERNAL TABLE order_items (
  order_item_id INT,
  order_item_order_id INT,
  order_item_product_id INT,
  order_item_quantity INT,
  order_item_subtotal FLOAT,
  order_item_product_price FLOAT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail_data_raw/order_items';

DROP TABLE IF EXISTS products;
CREATE EXTERNAL TABLE products (
  Product_id INT,
  Product_category_id INT,
  Product_description STRING,
  Product_price FLOAT,
  Product_image STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail_data_raw/products';

