wget https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/spark-etl/sparkmaprproject_2.11-0.1.0-SNAPSHOT.jar

 hadoop fs -rm -f -r  spark /user/mapr/pipeline/spark
hadoop fs -put spark /user/mapr/pipeline

spark-submit  --class RetailDataETL    --master yarn --deploy-mode client  sparkmaprproject_2.11-0.1.0-SNAPSHOT.jar 
spark-submit  --class RetailDataETL    --master local[*] sparkmaprproject_2.11-0.1.0-SNAPSHOT.jar 
 /opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="http://localhost:11000/oozie" -config job.properties -run

/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="http://localhost:11000/oozie" -info 0000010-231227103858475-oozie-mapr-W


grep "RetailDataETL" $SPARK_HOME/logs
yarn logs -applicationId <Application_Id> | grep "RetailDataETL"