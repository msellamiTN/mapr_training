
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.to_json
// 
import com.mapr.db.spark.sql._
// Step 1: Configure the Spark and Hive environment
val spark = SparkSession.builder
  .appName("Retail Data ETL")
  .config("spark.sql.warehouse.dir", "/user/mapr/hive/warehouse")
  .enableHiveSupport()
  .getOrCreate()

import spark.implicits._

val ordersDF = spark.table("orders")
ordersDF.show()
val orderItemsDF = spark.table("order_items")
orderItemsDF.show()
val productsDF = spark.table("products")
productsDF.show()
val categoriesDF = spark.table("categories")
categoriesDF.show()

val filteredOrdersDF = ordersDF.filter(!$"order_status".isin("CANCELED", "SUSPECTED_FRAUD"))
filteredOrdersDF.show()
val joinedDF = orderItemsDF.join(filteredOrdersDF, $"order_item_order_id" === $"order_id")
joinedDF.show()
val revenuePerProductDF = joinedDF.groupBy("order_item_product_id")
  .agg(
    sum("order_item_subtotal").as("revenue"),
    sum("order_item_quantity").as("quantity")
  )

val salesFactDF = revenuePerProductDF.join(productsDF, $"order_item_product_id" === $"product_id")
  .select(
    $"product_id".as("product_id"),
    $"product_category_id", // Include product_category_id here
    $"product_description".as("name"),
    $"revenue".as("CA")
  )
 // Step 6: Transform into the final DataFrame structure
// This step involves joining the sales fact data with the categories data.
// The join is based on the product_category_id from the salesFactDF and the category_id from categoriesDF.
// After the join, we group the data by category_id, which is also cast to a string and renamed as '_id' to align with the target JSON structure.
// The aggregation includes:
//   - 'first($"category_name")' to get the name of the category.
//   - 'sum($"CA")' to calculate the total revenue (CA) per category.
//   - 'collect_list(to_json(struct(...)))' to create a JSON array of product details.
//     Each product's details are structured and converted to a JSON string.
// The resulting DataFrame, transformedDF, has the structure of categories with their total revenue and a list of products in JSON format.

val transformedDF = salesFactDF.join(categoriesDF, $"product_category_id" === $"category_id")
  .groupBy($"category_id".cast("string").as("_id"))
  .agg(
    first($"category_name").as("category"),
    sum($"CA").as("CA"),
    collect_list(
      to_json(
        struct(
          $"product_id".as("product_id"),
          $"name",
          $"CA"
        )
      )
    ).as("products")
  )

 
transformedDF.show(false)

// Step 4-2: Save to MapR-DB
val tableName = "/user/mapr/retail_data_modeled/salesfact_db" // MapR-DB table path
transformedDF.saveToMapRDB(tableName, idFieldPath = "_id", createTable = true)
