DROP TABLE IF EXISTS categories;
CREATE EXTERNAL TABLE categories (
  category_id INT,
  category_department_id INT,
  category_name STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/categories';

DROP TABLE IF EXISTS orders;
CREATE EXTERNAL TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/orders';


CREATE EXTERNAL TABLE order_items (
  order_item_id INT,
  order_item_order_id INT,
  order_item_product_id INT,
  order_item_quantity INT,
  order_item_subtotal FLOAT,
  order_item_product_price FLOAT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/order_items';

DROP TABLE IF EXISTS products;
CREATE EXTERNAL TABLE products (
  Product_id INT,
  Product_category_id INT,
  Product_description STRING,
  Product_price FLOAT,
  Product_image STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '/user/mapr/retail-data-raw/products';


CREATE EXTERNAL TABLE intermediate_access_logs (
    ip STRING,
    date STRING,
    method STRING,
    url STRING,
    http_version STRING,
    code1 STRING,
    code2 STRING,
    dash STRING,
    user_agent STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.contrib.serde2.RegexSerDe'
WITH SERDEPROPERTIES (
    'input.regex' = '([^ ]*) - - \\[([^\\]]*)\\] "([^\ ]*) ([^\ ]*) ([^\ ]*)" (\\d*) (\\d*) "([^"]*)" "([^"]*)"',
    'output.format.string' = "%1$$s %2$$s %3$$s %4$$s %5$$s %6$$s %7$$s %8$$s %9$$s")
LOCATION '/user/mapr/retail-data-raw/logs_data';