
val spark = SparkSession.builder
  .appName("Retail Data ETL")
  .config("spark.sql.warehouse.dir", "/user/mapr/hive/warehouse")
  .enableHiveSupport()
  .getOrCreate()

import spark.implicits._

// Step 2: Read from Hive Tables
val ordersDF = spark.table("orders")
val orderItemsDF = spark.table("order_items")
val productsDF = spark.table("products")

// Step 3: Data Transformation
val filteredOrdersDF = ordersDF.filter(!$"order_status".isin("CANCELED", "SUSPECTED_FRAUD"))
val joinedDF = orderItemsDF.join(filteredOrdersDF, $"order_item_order_id" === $"order_id")
val revenuePerProductDF = joinedDF.groupBy("order_item_product_id").agg(sum("order_item_subtotal").as("revenue"))

// Join with the products DataFrame and select necessary columns
val salesFactDF = revenuePerProductDF.join(productsDF, $"order_item_product_id" === $"product_id")
  .select($"product_id".cast("string").as("product_id"), $"product_category_id", $"revenue") // Casting product_id to string

// Step 4-2: Save to MapR-DB
val tableName = "/user/mapr/retail_data_modeled/salesFact" // MapR-DB table path
salesFactDF.saveToMapRDB(tableName, idFieldPath = "product_id", createTable = true)
