#!/bin/bash
# Download Data and Ingest it using HDFS API

# Create a directory for retail-data and navigate into it
mkdir -p retail-data && cd retail-data

# Download datasets
wget "https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/orders.csv"
wget "https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/order_items.csv"
wget "https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/products.csv"
wget "https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/categories.csv"
wget "https://raw.githubusercontent.com/msellamiTN/Apache-Spark-Training/master/retail_db/access.log.zip"

unzip access.log.zip  

# Create directories in HDFS and upload files
hadoop fs -mkdir -p /user/mapr/retail-data-raw/logs_data
 hadoop fs -put access.log.zip /user/mapr/retail-data-raw/logs_data
hadoop fs -mkdir -p /user/mapr/retail-data-raw/categories 
hadoop fs -put categories.csv /user/mapr/retail-data-raw/categories/

hadoop fs -mkdir -p /user/mapr/retail-data-raw/products 
hadoop fs -put products.csv /user/mapr/retail-data-raw/products/ 

hadoop fs -mkdir -p /user/mapr/retail-data-raw/orders 
hadoop fs -put orders.csv /user/mapr/retail-data-raw/orders/ 

hadoop fs -mkdir -p /user/mapr/retail-data-raw/order_items
hadoop fs -put order_items.csv /user/mapr/retail-data-raw/order_items/ 

# Function to check file in HDFS
check_file_in_hdfs() {
    local hdfs_path=$1
    echo "Checking $hdfs_path in HDFS..."
    if hadoop fs -test -e "$hdfs_path"; then
        echo "File $hdfs_path exists in HDFS."
    else
        echo "File $hdfs_path does not exist in HDFS."
        exit 1
    fi
}

# Check if the files have been ingested successfully
check_file_in_hdfs "/user/mapr/retail-data-raw/logs_data/access.log.2"
check_file_in_hdfs "/user/mapr/retail-data-raw/categories/categories.csv"
check_file_in_hdfs "/user/mapr/retail-data-raw/products/products.csv"
check_file_in_hdfs "/user/mapr/retail-data-raw/orders/orders.csv"
check_file_in_hdfs "/user/mapr/retail-data-raw/order_items/order_items.csv"

echo "All files have been ingested successfully."
