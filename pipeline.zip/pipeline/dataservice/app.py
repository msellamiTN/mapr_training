from flask import Flask, jsonify, request
from mapr.ojai.storage.ConnectionFactory import ConnectionFactory
from mapr.ojai.ojai_query.QueryOp import QueryOp

app = Flask(__name__)
"""Create a connection, get store, insert new document into store"""
# create a connection
connection_string = "localhost:5678?auth=basic;user=mapr;password=mapr;ssl=false;" 
connection = ConnectionFactory.get_connection(connection_str=connection_string)
 
document_store = connection.get_store('/user/mapr/retail_data_modeled/salesfact-db')

@app.route('/query_by_category', methods=['GET'])
def query_by_category():
    category = request.args.get('category')
    options = {
    'ojai.mapr.query.timeout-milliseconds': 1000,
    }
    query_condition = connection.new_condition().is_('category', QueryOp.EQUAL, category).build()
    query_result = document_store.find(connection.new_query().where(query_condition).build(),options)

    results = [doc.as_dictionary() for doc in query_result]

    connection.close()
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
