from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, month, dayofmonth, quarter
from pyspark.sql.types import StructType, IntegerType, DateType, StringType
from pyspark.sql.functions import monotonically_increasing_id
 
# Initialize Spark Session with Hive support
spark = SparkSession.builder \
    .appName("Spark Python to MapR-DB") \
    .enableHiveSupport() \
    .getOrCreate()
 
# Define the schema for the DataFrame
schema = StructType() \
    .add("OrderID", IntegerType(), True) \
    .add("OrderDate", DateType(), True) \
    .add("CustomerID", IntegerType(), True) \
    .add("OrderStatus", StringType(), True)
 
# Load the DataFrame with the specified schema
df = spark.read.format("csv") \
    .option("delimiter", ",") \
    .option("quote", "") \
    .option("header", "false") \
    .schema(schema) \
    .load("/user/mapr/spark-maprdb")
 
# Clean and augment the DataFrame  # Add id column and cast it to string
cleaned_df = df \
    .na.fill(0, ["OrderID", "CustomerID"]) \
    .withColumn("_id", monotonically_increasing_id().cast("string")) \
    .withColumn("OrderYear", year("OrderDate")) \
    .withColumn("OrderMonth", month("OrderDate")) \
    .withColumn("OrderDay", dayofmonth("OrderDate")) \
    .withColumn("OrderQuarter", quarter("OrderDate"))
 
# Export to Mapr-DB
table_path = "/user/mapr/table-pyspark"
cleaned_df.write.format("com.mapr.db.spark.sql.DefaultSource") \
    .option("tablePath", table_path) \
    .option("createTable", True) \
    .save()
